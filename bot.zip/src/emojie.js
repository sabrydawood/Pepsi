module.exports = {
	APROVED: "<:approved:803657926149275658>",
	REMOVED: "<:removed:803657720375935008>"
}